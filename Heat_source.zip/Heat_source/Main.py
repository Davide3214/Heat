# Importo pygame
import pygame
import time
import pygame.mixer

# Inizializzo pygame e mixer e creo la finestra
pygame.init()
pygame.mixer.init()
Schreen = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Heat")
Schreen.fill("Red")

# Carico la musica e i suoni
pygame.mixer.music.load("Music_and_sounds/Background_music.mp3")

# Carico gli sprite e li adatto
Pizza = pygame.image.load("Sprites/Pizza.png")
Pizza = pygame.transform.scale(Pizza, (50, 50))
Monster = pygame.image.load("Sprites/Heat_monster.png")
Monster = pygame.transform.scale(Monster, (500,500))
Burned_pizza = pygame.image.load("Sprites/Bruised_Pizza.png")
Burned_pizza = pygame.transform.scale(Burned_pizza, (50,50))
Logo = pygame.image.load("Sprites/Heater.png")
pygame.display.set_icon(Logo)

# Carico il font e creo il testo
font = pygame.font.Font("MGPixel.otf", 36)
text = font.render("You burned the pizza! You lost", True, (255, 255, 255))

# Creo il punteggio iniziale
score = 0

# Faccio partire la musica
pygame.mixer.music.play(-1)

# Creo l'evento running
running = True
start_time = time.time()
game_duration = 10
Game_over = 15
reset_timer = False
while running:
    # Creo l'evento della chiusura
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False



    # Faccio partire il timer
    current_time = time.time()
    elapsed_time = current_time - start_time

    if reset_timer:
        start_time = time.time()
        reset_timer = False

    # Faccio in modo che ci sia un un'avviso visivo per avvertire che la pizza si sta bruciando e che dia un punto se lo si ferma in tempo resettando il timer
    if elapsed_time > game_duration:
        Schreen.blit(Monster, (0, 0))
        Schreen.blit(Burned_pizza, (230, 360))
        keys = pygame.key.get_pressed()
        if pygame.mouse.get_pressed()[0]:
            start_time = time.time()
            score += 1


    # Faccio in modo che il gioco si chiuda 5 secondi dopo che la pizza si è bruciata
    if elapsed_time > Game_over:
        text_rect = text.get_rect()
        text_rect.center = (250, 100)
        Schreen.blit(text, text_rect)
        pygame.display.update()
        time.sleep(5)
        running = False



    # rendo il punteggio visibile
    score_text = font.render('Saved Pizzas: ' + str(score), True, (255, 255, 255))
    Schreen.blit(score_text, (10, 10))
    pygame.display.update()

    # Rendo gli sprite visibili
    Schreen.blit(Monster, (0,0))
    Schreen.blit(Pizza, (230, 360))



    # Faccio aggiornare lo schermo
    pygame.display.update()